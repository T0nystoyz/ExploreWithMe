package ru.practicum.stats_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StatServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
