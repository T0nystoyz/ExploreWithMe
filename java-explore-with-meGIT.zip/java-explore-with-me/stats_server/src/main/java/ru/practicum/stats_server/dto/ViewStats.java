package ru.practicum.stats_server.dto;


public interface ViewStats {
    String getApp();

    String getUri();

    int getHits();
}
